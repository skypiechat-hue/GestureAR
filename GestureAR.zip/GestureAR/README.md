# GestureAR (Samsung S23 Ultra)
## Fastest build (no Android Studio needed)
1. Create a GitHub repo, upload this folder's contents (keep the .github folder), push.
2. Actions tab > "Build APK" > wait ~5 min > download artifact GestureAR-debug-apk > app-debug.apk.
   The workflow downloads the hand model and compiles for you.
3. Send the APK to the phone and install it (allow unknown sources). ARCore (Google Play Services for AR) must be installed.
## Android Studio build
Download https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
into app/src/main/assets/, open the folder, Run.
## Use
Initialize system > pan room > Finish scan. Show grid toggles room grid.
Pinch = create/grow cube lines (hand back = more cubes) | fist = move | claw + twist = resize | open hand = nothing
