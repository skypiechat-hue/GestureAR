package com.example.gesturear

import android.Manifest
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix as BMatrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.opengl.Matrix
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.ar.core.Config
import com.google.ar.core.Frame
import com.google.ar.core.TrackingState
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import io.github.sceneview.ar.ARSceneView
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Scale
import io.github.sceneview.node.CylinderNode
import io.github.sceneview.node.Node
import java.io.ByteArrayOutputStream
import kotlin.math.*

class MainActivity : AppCompatActivity() {
    enum class G { NONE, CREATE, MOVE, RESIZE }
    class Obj(var n: Int, var node: Node)

    lateinit var sv: ARSceneView
    lateinit var hl: HandLandmarker
    lateinit var status: TextView
    val objs = mutableListOf<Obj>()
    var active: Obj? = null
    var cur = G.NONE; var cand = G.NONE; var candCount = 0; var tick = 0
    var refSize = 0f; var depth = 0.5f; var startScale = 1f; var startAngle = 0f
    var scanning = false; var ready = false; var gridShown = false
    val mat by lazy { sv.materialLoader.createColorInstance(Color.CYAN) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 1)
        sv = ARSceneView(this)
        sv.configureSession { _, c -> c.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL }
        sv.planeRenderer.isVisible = false
        hl = HandLandmarker.createFromOptions(this, HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.IMAGE).setNumHands(1).build())

        status = TextView(this).apply { setTextColor(Color.WHITE); setBackgroundColor(0x88000000.toInt()); setPadding(24, 16, 24, 16); text = "Tap Initialize system" }
        val init = Button(this).apply { text = "Initialize system" }
        val grid = Button(this).apply { text = "Show grid" }
        init.setOnClickListener {
            if (!scanning) { scanning = true; ready = false; sv.planeRenderer.isVisible = true
                init.text = "Finish scan"; status.text = "Move the phone slowly around the room, then tap Finish scan" }
            else { scanning = false; ready = true; sv.planeRenderer.isVisible = gridShown
                init.text = "Re-initialize"; status.text = "Room mapped. Use your hand." }
        }
        grid.setOnClickListener { gridShown = !gridShown; sv.planeRenderer.isVisible = gridShown || scanning
            grid.text = if (gridShown) "Hide grid" else "Show grid" }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(status); addView(init); addView(grid) }
        setContentView(FrameLayout(this).apply { addView(sv); addView(bar, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP)) })

        sv.onSessionUpdated = { _, frame -> if (frame.camera.trackingState == TrackingState.TRACKING) process(frame) }
    }

    // ---------- gesture classification (MediaPipe landmarks: 0 wrist, 4 thumb tip, 8 index tip, 9 middle MCP) ----------
    fun d(lm: List<NormalizedLandmark>, a: Int, b: Int) = hypot(lm[a].x() - lm[b].x(), lm[a].y() - lm[b].y())
    fun classify(lm: List<NormalizedLandmark>): G {
        val size = d(lm, 0, 9)
        val ext = listOf(8 to 6, 12 to 10, 16 to 14, 20 to 18).count { d(lm, 0, it.first) > d(lm, 0, it.second) * 1.1f }
        val pinch = d(lm, 4, 8)
        return when {
            pinch < size * 0.35f -> G.CREATE          // image 1: thumb + index touching
            ext == 0 && pinch < size * 0.8f -> G.MOVE // image 3: fist
            ext >= 3 -> G.NONE                        // image 2: open hand
            else -> G.RESIZE                          // image 4: curved claw, twist to resize
        }
    }

    fun process(frame: Frame) {
        if (!ready || ++tick % 3 != 0) return
        val bmp = toBitmap(frame) ?: return
        val lms = hl.detect(BitmapImageBuilder(bmp).build()).landmarks()
        val lm = lms.firstOrNull()
        val g = if (lm == null) G.NONE else classify(lm)
        if (g == cand) candCount++ else { cand = g; candCount = 1 }
        if (candCount >= 2 && cand != cur) { cur = cand; if (lm != null) onEnter(frame, lm) }
        if (lm != null) onHold(frame, lm)
        status.text = "Gesture: $cur  ${active?.let { "cubes: ${it.n}^3" } ?: ""}"
    }

    fun onEnter(frame: Frame, lm: List<NormalizedLandmark>) {
        val u = lm[9].x(); val v = lm[9].y()
        when (cur) {
            G.CREATE -> { refSize = d(lm, 0, 9)
                val o = Obj(1, lattice(1)); o.node.worldPosition = pointAt(frame, u, v, 0.5f)
                sv.addChildNode(o.node); objs += o; active = o }
            G.MOVE -> { val cam = camPos(frame)
                active = objs.minByOrNull { dist(pointAt(frame, u, v, dist(cam, it.node.worldPosition)), it.node.worldPosition) }
                active?.let { depth = dist(cam, it.node.worldPosition) } }
            G.RESIZE -> active?.let { startScale = it.node.scale.x; startAngle = angle(lm) }
            else -> {}
        }
    }

    fun onHold(frame: Frame, lm: List<NormalizedLandmark>) {
        val o = active ?: return
        when (cur) {
            G.CREATE -> { // hand moves back (smaller in image) -> more cubes
                val n = (1 + ((refSize / d(lm, 0, 9)) - 1f) * 6f).roundToInt().coerceIn(1, 5)
                if (n != o.n) { val old = o.node; val nn = lattice(n)
                    nn.worldPosition = old.worldPosition; nn.scale = old.scale
                    sv.removeChildNode(old); old.destroy(); sv.addChildNode(nn); o.node = nn; o.n = n }
            }
            G.MOVE -> o.node.worldPosition = pointAt(frame, lm[9].x(), lm[9].y(), depth)
            G.RESIZE -> { val a = angle(lm) - startAngle
                val s = (startScale * exp(atan2(sin(a), cos(a)))).coerceIn(0.3f, 4f)
                o.node.scale = Scale(s, s, s) }
            else -> {}
        }
    }

    fun angle(lm: List<NormalizedLandmark>) = atan2(lm[9].y() - lm[0].y(), lm[9].x() - lm[0].x())

    // ---------- cube lattice drawn as lines: n x n x n cubes = (n+1)^2 lines per axis ----------
    fun lattice(n: Int): Node {
        val root = Node(sv.engine); val s = 0.06f; val L = n * s; val off = -L / 2
        fun line(p: Position, r: Rotation) = root.addChildNode(
            CylinderNode(sv.engine, radius = 0.0015f, height = L, materialInstance = mat).apply { position = p; rotation = r })
        for (a in 0..n) for (b in 0..n) {
            line(Position(0f, off + a * s, off + b * s), Rotation(0f, 0f, 90f)) // along X
            line(Position(off + a * s, 0f, off + b * s), Rotation(0f, 0f, 0f))  // along Y
            line(Position(off + a * s, off + b * s, 0f), Rotation(90f, 0f, 0f)) // along Z
        }
        return root
    }

    // ---------- camera math ----------
    fun camPos(f: Frame) = Position(f.camera.pose.tx(), f.camera.pose.ty(), f.camera.pose.tz())
    fun dist(a: Position, b: Position) = sqrt((a.x - b.x).pow(2) + (a.y - b.y).pow(2) + (a.z - b.z).pow(2))
    fun pointAt(f: Frame, u: Float, v: Float, depth: Float): Position {
        val p = FloatArray(16); val w = FloatArray(16); val vp = FloatArray(16); val inv = FloatArray(16)
        f.camera.getProjectionMatrix(p, 0, 0.05f, 50f); f.camera.getViewMatrix(w, 0)
        Matrix.multiplyMM(vp, 0, p, 0, w, 0); Matrix.invertM(inv, 0, vp, 0)
        fun un(z: Float): FloatArray { val o = FloatArray(4)
            Matrix.multiplyMV(o, 0, inv, 0, floatArrayOf(2 * u - 1, 1 - 2 * v, z, 1f), 0)
            return floatArrayOf(o[0] / o[3], o[1] / o[3], o[2] / o[3]) }
        val a = un(-1f); val b = un(1f)
        val dx = b[0] - a[0]; val dy = b[1] - a[1]; val dz = b[2] - a[2]; val l = sqrt(dx * dx + dy * dy + dz * dz)
        val c = camPos(f)
        return Position(c.x + dx / l * depth, c.y + dy / l * depth, c.z + dz / l * depth)
    }

    // ARCore CPU image (YUV) -> upright bitmap for MediaPipe (portrait: rotate 90 deg)
    fun toBitmap(f: Frame): Bitmap? {
        val img = try { f.acquireCameraImage() } catch (e: Exception) { return null }
        img.use {
            val y = it.planes[0].buffer; val u = it.planes[1].buffer; val v = it.planes[2].buffer
            val ys = y.remaining(); val us = u.remaining(); val vs = v.remaining()
            val nv = ByteArray(ys + us + vs)
            y.get(nv, 0, ys); v.get(nv, ys, vs); u.get(nv, ys + vs, us)
            val out = ByteArrayOutputStream()
            YuvImage(nv, ImageFormat.NV21, it.width, it.height, null).compressToJpeg(Rect(0, 0, it.width, it.height), 70, out)
            val raw = BitmapFactory.decodeByteArray(out.toByteArray(), 0, out.size())
            return Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, BMatrix().apply { postRotate(90f) }, true)
        }
    }
}
