plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.gesturear"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.gesturear"; minSdk = 28; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "task" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("io.github.sceneview:arsceneview:2.2.1")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}
